import python_vad
python_vad.start()
